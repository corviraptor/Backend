import json
from pathlib import Path

here = Path('.')

for biome_file in here.glob('**/*.json'):
    print(biome_file)
    with open(biome_file, 'r') as r_fp:
        j = json.load(r_fp)

    j['has_precipitation'] = True
    j['temperature_modifier'] = 'none'
    j['temperature'] = -10.0

    with open(biome_file, 'w') as w_fp:
        json.dump(j, w_fp)